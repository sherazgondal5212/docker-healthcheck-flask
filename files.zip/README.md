# Project 1.2: Healthchecked Flask Container

A Flask API in Docker with a `HEALTHCHECK`, so Docker reports whether the app is actually ready, not just running. Built and tested in AWS CloudShell on 13 November 2026. Builds on [Project 1.1](https://github.com/sherazgondal5212/devops-portfolio/tree/main/01-docker-flask).

`Docker` `Python 3.12` `Flask 3.0.3` `Gunicorn 22.0.0` `HEALTHCHECK` `AWS CloudShell`

## 1. Hero: outcomes at a glance

| Metric | Result |
|---|---|
| Image | `gda-flask:1.2`, 126 MB |
| Runs as | `appuser`, uid 1000 (not root) |
| Health status | `starting` at start, `healthy` by 15 s |
| Failure test | `unhealthy` after failed checks (FailingStreak 3) |
| Endpoints | 2 of 2 returned the expected JSON |

## 2. Architecture diagram

```mermaid
flowchart LR
  C[Client: curl] -->|port 5000| H[Docker host: AWS CloudShell]
  H --> G
  subgraph K[Container gda-flask:1.2, user appuser uid 1000]
    G[Gunicorn 0.0.0.0:5000] --> F[Flask app: / and /health]
    HC[HEALTHCHECK every 10 s] -->|GET /health| G
  end
  D[Docker Engine] -. reads check result .-> HC
```

## 3. Terminal screenshots

Real output from AWS CloudShell, 13 November 2026.

**Status right after start, then after 15 seconds**

![Health starting](screenshots/02-screen-health-starting.png)
![Healthy](screenshots/03-screen-healthy.png)

```
$ docker ps --format "table {{.Names}}\t{{.Status}}"
flask-health   Up Less than a second (health: starting)
$ sleep 15
flask-health   Up 15 seconds (healthy)
```

**Failure test: container marked unhealthy but still serving**

![Unhealthy](screenshots/05-screen-unhealthy.png)

```
flask-broken   Up 20 seconds (unhealthy)
flask-health   Up About a minute (healthy)
$ curl localhost:5001/health
{"status":"ok"}
```

**Image size, user, Dockerfile**

![Evidence](screenshots/06-screen-evidence.png)

```
gda-flask    1.2    b98fba91c6c7    126MB
$ docker exec flask-health id
uid=1000(appuser) gid=1000(appuser) groups=1000(appuser)
```

## 4. Technical workflow

1. Copied Project 1.1 into `02-docker-healthcheck` and kept a backup of its Dockerfile for comparison.
2. Added `PYTHONUNBUFFERED`, an explicit uid 1000 for `appuser`, and a `HEALTHCHECK` that calls `/health` with Python's `urllib` (the slim image has no curl).
3. Built `gda-flask:1.2` and started `flask-health`.
4. Checked the status right after start and again after 15 seconds.
5. Started `flask-broken` with a health command pointed at port 9999, which nothing listens on.
6. Checked its status, then called its real `/health` endpoint.
7. Collected image size, user, logs and Dockerfile, then removed both containers.

## 5. Testing and evidence

| Test | Result | Evidence |
|---|---|---|
| GET / | Pass | Message and version 1.2 returned |
| GET /health | Pass | `{"status":"ok"}` |
| Gunicorn startup | Pass | Gunicorn 22.0.0 started, one sync worker booted |
| Non-root user | Pass | `uid=1000(appuser)` |
| Health after start | Pass | `starting` at under 1 s, `healthy` at 15 s |
| Failure test | Pass | `unhealthy`, `ExitCode: 1`, `FailingStreak: 3` |
| App while unhealthy | Observed | `/health` still returned ok and the container stayed `Up` |
| Re-test of the 1.1 startup race | Not done | Not re-run in this project |

**Finding:** plain Docker only labels a container `unhealthy`. It does not restart or stop it. Acting on that label is the job of an orchestrator such as ECS or Kubernetes, which is covered in Phase 4.

**Limits:** the failure test points the check at a wrong port. It simulates a failed check, not a crashed app. The exact reason for the `Errno 99` error was not investigated, so none is claimed.

## 6. Automation scripts breakdown

| File | What it does |
|---|---|
| `Dockerfile` | Builds from python:3.12-slim, installs pinned dependencies, creates `appuser` (uid 1000), adds the `HEALTHCHECK`, starts Gunicorn on port 5000 |
| `app/app.py` | `/` route (reads `APP_VERSION`) and `/health` route |
| `app/requirements.txt` | Pins Flask 3.0.3 and Gunicorn 22.0.0 |
| `.dockerignore` | Keeps `.git`, caches and `.env` out of the build |

Changes from 1.1: `PYTHONDONTWRITEBYTECODE` and `PYTHONUNBUFFERED` set, `appuser` created with `--uid 1000`, `HEALTHCHECK` added, `--bind` used instead of `-b`.

```
docker build -t gda-flask:1.2 .
docker run -d --name flask-health -p 5000:5000 -e APP_VERSION=1.2 gda-flask:1.2
docker ps --format "table {{.Names}}\t{{.Status}}"
docker inspect --format '{{json .State.Health}}' flask-health
```

HEALTHCHECK settings: interval 10 s, timeout 3 s, start period 5 s, retries 3. The 10 s interval is chosen for a quick demo; 30 s is common in production.

## 7. Project outcomes and metrics

- **126 MB** image size (1.1 showed 134 MB; the cause of the difference was not investigated)
- **uid 1000** non-root runtime user
- **15 s** from start to `healthy` in the observed run
- **3** failing checks recorded in the failure test
- **2 of 2** endpoints returned the expected JSON

## 8. GitHub and live links

Local container project, so there is no live URL.

- [Project 1.2 on GitHub](https://github.com/sherazgondal5212/docker-healthcheck-flask)
- [Project 1.2 portfolio page](https://sherazgondal5212.github.io/docker-healthcheck-flask/)
- [Full portfolio repo (Project 1.1)](https://github.com/sherazgondal5212/devops-portfolio)
- [Project 1.1 portfolio page](https://sherazgondal5212.github.io/devops-portfolio/)

Next: Project 1.3 runs Flask with a database using Docker Compose.

## 9. Gondal Digital Agency

A reliable technology partner for international startups and businesses. Cloud and DevOps engineering on AWS.

[gondaldigitalagency.com](https://gondaldigitalagency.com)
